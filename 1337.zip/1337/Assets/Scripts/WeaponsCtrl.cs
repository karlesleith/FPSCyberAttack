﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponsCtrl : MonoBehaviour {

    //Insitlaze Variables
    public string weaponName = "MegaBuster";
    public float weaponDamage = 100f;
    public float weaponRange = 10f;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
